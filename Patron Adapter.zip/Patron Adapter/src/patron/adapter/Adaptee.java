/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patron.adapter;

/**
 *
 * @author tracy
 */
//clase del cargador del celular
public class Adaptee {

    public void CargadorDeIPhone4sA36Plus() {
        System.out.println("Cargando IPhone4s con cargador adaptado de IPhone 36 plus");

    }
}
